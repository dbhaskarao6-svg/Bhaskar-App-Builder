# Bhaskar App Builder V3 — Real APK Build Workflow

## What V3 adds
- GitHub Actions cloud build workflow for Android debug APK.
- In-app Build APK panel with exact cloud-build steps.
- APK artifact upload from GitHub Actions.
- Build output and error visibility through the GitHub Actions run logs.
- Existing V2 editor features retained.

## Build an APK using GitHub Actions
1. Create a GitHub repository.
2. Upload the complete contents of this project ZIP to the repository root. Keep the `.github/workflows/android-build.yml` file and the `android/` folder.
3. Push/commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and open the latest run.
6. Wait for the **Build debug APK** step to finish successfully.
7. In the run's **Artifacts** section, download `Bhaskar-App-Builder-debug-apk`.
8. Extract the artifact ZIP. It contains `app-debug.apk`, which can be installed on a compatible Android device. Android may ask permission to install from that source.

The workflow runs on GitHub-hosted cloud machines. It requires a GitHub account and internet access. The APK is not built on the phone itself. The in-app button cannot start a GitHub build until the project has been uploaded to a GitHub repository.

## Local Android Studio build
Open `android/` in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important limitations
- This workflow builds the Android WebView wrapper project as a debug APK. It does not yet compile arbitrary Java/Kotlin projects created in the editor.
- Cloud build is GitHub Actions-based, not a direct one-tap authenticated integration from inside the app.
- No release signing key is included. A production Play Store release needs a securely managed signing configuration.
- The workflow uses Gradle 8.9 and Android Gradle Plugin 8.7.3.
