const languages=[
{name:'HTML',file:'index.html',mode:'xml',code:'<!doctype html>\n<html>\n<head><title>My App</title></head>\n<body>\n  <h1>Hello, Bhaskar!</h1>\n  <p>My first web app.</p>\n</body>\n</html>'},
{name:'CSS',file:'style.css',mode:'css',code:'body { font-family: Arial; background: #eef4ff; padding: 24px; }\nh1 { color: #245bd6; }'},
{name:'JavaScript',file:'script.js',mode:'javascript',code:'console.log("Hello from JavaScript!");\nconst total = 10 + 20;\nconsole.log("Total:", total);'},
{name:'Python',file:'main.py',mode:'python',code:'print("Hello from Python!")\nname = "Bhaskar"\nprint("Welcome,", name)'},
{name:'Java',file:'Main.java',mode:'text/x-java',code:'public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello from Java");\n  }\n}'},
{name:'Kotlin',file:'Main.kt',mode:'text/x-kotlin',code:'fun main() {\n    println("Hello from Kotlin")\n}'},
{name:'XML',file:'activity_main.xml',mode:'xml',code:'<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"\n    android:layout_width="match_parent"\n    android:layout_height="match_parent"\n    android:orientation="vertical">\n    <TextView android:layout_width="wrap_content"\n        android:layout_height="wrap_content"\n        android:text="Hello Bhaskar" />\n</LinearLayout>'},
{name:'JSON',file:'data.json',mode:'application/json',code:'{\n  "app": "Bhaskar App Builder",\n  "version": 2,\n  "offline": true\n}'},
{name:'SQL',file:'database.sql',mode:'text/x-sql',code:'CREATE TABLE students (\n  id INTEGER PRIMARY KEY,\n  name TEXT NOT NULL\n);\nSELECT * FROM students;'}
];
let active=0, files=JSON.parse(localStorage.getItem('bab_files_v2')||localStorage.getItem('bab_files')||'{}'), cm=null;
languages.forEach(x=>{if(!files[x.file])files[x.file]=x.code});
const $=id=>document.getElementById(id);
function currentValue(){return cm?cm.getValue():$('code').value}
function setValue(v){if(cm)cm.setValue(v);else $('code').value=v}
function persist(){localStorage.setItem('bab_files_v2',JSON.stringify(files));localStorage.setItem('bab_files',JSON.stringify(files));$('savedState').textContent='Saved locally';renderFiles()}
function renderFiles(){$('fileList').innerHTML='';Object.keys(files).forEach(f=>{let b=document.createElement('button');b.className='file'+(f===languages[active].file?' active':'');b.textContent='▤  '+f;b.onclick=()=>{let i=languages.findIndex(x=>x.file===f);if(i>=0){saveCurrent();active=i;loadLang()}else{$('currentFile').textContent=f;setValue(files[f])}};$('fileList').appendChild(b)})}
function modeFor(l){return l.mode}
function initEditor(){if(window.CodeMirror){cm=CodeMirror.fromTextArea($('code'),{lineNumbers:true,mode:modeFor(languages[active]),theme:'dracula',autoCloseBrackets:true,matchBrackets:true,indentUnit:2,tabSize:2,lineWrapping:false,extraKeys:{"Ctrl-S":()=>{saveCurrent();out('Saved locally.')},"Ctrl-Space":"autocomplete"}});cm.on('change',()=>{$('savedState').textContent='Unsaved changes';files[languages[active].file]=cm.getValue();updateLineInfo()});}else{$('code').addEventListener('input',()=>{$('savedState').textContent='Unsaved changes';files[languages[active].file]=$('code').value;updateLineInfo()})}}
function updateLineInfo(){let v=currentValue(),n=v.split('\n').length;$('lineInfo').textContent='Line '+(cm?cm.getCursor().line+1:1)+' · '+n+' lines'}
function loadLang(){$('langTabs').innerHTML='';languages.forEach((l,i)=>{let b=document.createElement('button');b.className='tab'+(i===active?' active':'');b.textContent=l.name;b.onclick=()=>{saveCurrent();active=i;loadLang()};$('langTabs').appendChild(b)});$('currentFile').textContent=languages[active].file;if(cm){cm.setOption('mode',modeFor(languages[active]));cm.setValue(files[languages[active].file]);}else $('code').value=files[languages[active].file];updateLineInfo();renderFiles()}
function saveCurrent(){files[languages[active].file]=currentValue();persist()}
function out(s){$('output').textContent=String(s)}
$('code').value=files[languages[active].file];initEditor();loadLang();
$('saveBtn').onclick=()=>{saveCurrent();out('Saved to this device.')};
$('newFile').onclick=()=>{let name=prompt('New file name (example: notes.txt)');if(name&&!files[name]){files[name]='';persist();let i=languages.findIndex(x=>x.file===name);if(i>=0){active=i;loadLang()}else{$('currentFile').textContent=name;setValue('')}}};
$('clearBtn').onclick=()=>out('');
$('refreshPreview').onclick=()=>preview();
function preview(){saveCurrent();let html=files['index.html']||'<h2>No index.html found</h2>',css=files['style.css']||'',js=files['script.js']||'';let doc=html.replace('</head>',`<style>${css}</style></head>`).replace('</body>',`<script>try{${js}}catch(e){document.body.insertAdjacentHTML('beforeend','<pre>'+e+'</pre>')}<\/script></body>`);$('preview').srcdoc=doc}
$('runBtn').onclick=async()=>{saveCurrent();let l=languages[active],code=currentValue();
if(l.name==='HTML'){preview();out('HTML preview refreshed.')}
else if(l.name==='CSS'){preview();out('CSS applied to live preview.')}
else if(l.name==='JavaScript'){let logs=[];try{const safeConsole={log:(...a)=>logs.push(a.join(' ')),error:(...a)=>logs.push('ERROR: '+a.join(' ')),warn:(...a)=>logs.push('WARN: '+a.join(' '))};new Function('console',code)(safeConsole);out(logs.join('\n')||'JavaScript executed.')}catch(e){out('Error: '+e.message)}}
else if(l.name==='Python'){out('Loading Python runtime…');try{if(!window.loadPyodide){let s=document.createElement('script');s.src='https://cdn.jsdelivr.net/pyodide/v0.27.7/full/pyodide.js';document.head.appendChild(s);await new Promise((res,rej)=>{s.onload=res;s.onerror=rej})}window.pyodide=window.pyodide||await loadPyodide();let result=await window.pyodide.runPythonAsync(`import sys, io\n_buf=io.StringIO()\n_old=sys.stdout\nsys.stdout=_buf\ntry:\n exec(${JSON.stringify(code)})\nexcept Exception as e:\n print(type(e).__name__ + ": " + str(e))\nsys.stdout=_old\n_buf.getvalue()`);out(result||'Python finished (no output).')}catch(e){out('Python runtime error: '+e.message+'\nFirst run needs internet to download Pyodide.')}}
else if(l.name==='JSON'){try{JSON.parse(code);out('Valid JSON ✓')}catch(e){out('JSON Error: '+e.message)}}
else if(l.name==='SQL'){out('SQL editor ready. Database execution is not included in V2.')}
else out(l.name+' editor ready. Native compilation is not included yet.');
};
$('themeBtn').onclick=()=>document.body.classList.toggle('light');
$('fullBtn').onclick=()=>{let el=document.querySelector('.editor');el.classList.toggle('fullscreen');$('fullBtn').textContent=el.classList.contains('fullscreen')?'✕ Exit Fullscreen':'⛶ Fullscreen';if(cm)setTimeout(()=>cm.refresh(),100)};
const words=['const','let','var','function','return','console.log','if','else','for','while','class','import','def','print','async','await','document','addEventListener'];
function showSuggestions(){if(cm&&window.CodeMirror&&CodeMirror.showHint){CodeMirror.showHint(cm,()=>{let cur=cm.getCursor(),line=cm.getLine(cur.line),start=cur.ch;while(start&&/[\\w.$]/.test(line.charAt(start-1)))start--;let token=line.slice(start,cur.ch).toLowerCase();return {list:words.filter(w=>w.toLowerCase().startsWith(token)&&w.toLowerCase()!==token).map(w=>({text:w,displayText:w})),from:CodeMirror.Pos(cur.line,start),to:cur}}, {completeSingle:false});}else out('Suggestions are available when the online editor library loads.')}
$('suggestBtn').onclick=showSuggestions;
$('code').addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();let t=e.target,a=t.selectionStart,b=t.selectionEnd;t.value=t.value.slice(0,a)+'  '+t.value.slice(b);t.selectionStart=t.selectionEnd=a+2}});
document.querySelectorAll('[data-snippet]').forEach(b=>b.onclick=()=>{let snippets={heading:'<h2>New Heading</h2>',paragraph:'<p>Write your text here.</p>',button:'<button type="button">Click me</button>',image:'<img src="https://via.placeholder.com/300x160" alt="Sample image">',card:'<div class="card"><h3>Card title</h3><p>Card description goes here.</p></div>'};if(active!==0){active=0;loadLang()}let v=currentValue(),insert=snippets[b.dataset.snippet];setValue(v+'\n'+insert);files['index.html']=currentValue();saveCurrent();out(b.textContent.trim()+' added to index.html. Refresh preview to view it.')});
$('buildBtn').onclick=()=>{const p=$('buildPanel');p.hidden=!p.hidden;if(!p.hidden)p.scrollIntoView({behavior:'smooth',block:'start'});};
const buildText='Bhaskar App Builder V3 APK build steps:\n1. Download and extract the complete V3 project ZIP.\n2. Upload all extracted contents to a GitHub repository root. Keep android/ and .github/workflows/android-build.yml.\n3. Open GitHub Actions and select Build Android APK.\n4. Open the latest successful run and download the Bhaskar-App-Builder-debug-apk artifact.\n5. Extract the artifact ZIP to get app-debug.apk.\nCloud build runs on GitHub, not directly on the phone.';
if($('copyBuildSteps'))$('copyBuildSteps').onclick=async()=>{try{await navigator.clipboard.writeText(buildText);out('Build steps copied.');}catch(e){out(buildText)}};
if($('openGithub'))$('openGithub').onclick=()=>window.open('https://github.com','_blank','noopener');
window.addEventListener('online',status);window.addEventListener('offline',status);function status(){$('netStatus').textContent=navigator.onLine?'Online':'Offline mode'}status();preview();
